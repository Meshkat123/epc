<p>Are Your Sure You want to delete it?</p>
<div class="modal-footer">
	<button type="button" class="btn btn-default waves-effect " data-dismiss="modal">Close</button>
	<a href="{{url('deleteAccountCategory/'.$id)}}" class="text-light"><button type="button" class="btn btn-primary waves-effect waves-light ">Yes</button></a>
</div>